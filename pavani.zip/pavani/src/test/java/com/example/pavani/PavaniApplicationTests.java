package com.example.pavani;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PavaniApplicationTests {

	@Test
	void contextLoads() {
	}

}
