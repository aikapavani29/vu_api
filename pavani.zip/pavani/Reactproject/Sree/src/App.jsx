import { BrowserRouter, Route, Routes } from "react-router-dom";
import Register from "./Register";
import Login from "./Login";
import Home from "./Home";
import Admin from "./Admin";
import AddBook from "./book/AddBook";
import AuthorBook from "./book/AuthorBook";
import Library from "./Library";
import ViewAll from "./book/ViewAll";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/reg" element={<Register />} />
        <Route path="/log" element={<Login />} />
        <Route path="/admin" element={<Admin />} />
        
        <Route path="/abook" element={<AddBook />} />
        <Route path="/vauthorbooks" element={<AuthorBook />} />
        <Route path="/Library" element={<Library/>}/>
        <Route path="/viewall" element={<ViewAll/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
