import axios from "axios"
import { useState } from "react"

function AuthorBook()
{
    const [form, setform] = useState({
        author: ""
    })

    const [result, setresult] = useState([])

    const submitform = async (e) =>
    {
        e.preventDefault()
        const response = await axios.post(`http://localhost:2913/book/authorform/${form.author}`)
        setresult(response.data)
        alert(response.data)
        
    }

    const changedata = (e) =>
    {
        setform({...form, [e.target.name]: e.target.value})
    }

    return(
        <>
        <h1>Search Books by Author</h1>
        <form onSubmit={submitform}>
            <input onChange={changedata} type="text" name="author" placeholder="enter author" value={form.author} /><br/>
            <button type="submit">Search</button>
        </form>

        <ul>
            {
                result.map((x, idx) => (
                    <li key={idx}>
                        {x.title} by {x.author} {x.description} <br />
                    </li>
                ))
            }
        </ul>
        </>
    )
}

export default AuthorBook
