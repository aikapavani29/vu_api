
import axios from "axios"
import { useState } from "react"

function Register()
{

    const [form,setform]=useState(
        {
            username:"",
            email:"",
            password:""
        }
    )

    const submitform = async (e) =>
    {
        e.preventDefault()
        const response=await axios.post("http://localhost:2913/register",form)
        alert(response.data)
    }

    const Changedata = (e) =>
    {
        setform({...form,[e.target.name]:e.target.value})
    }

    return(
        <>
           <h1>Registeration page</h1>
           <form onSubmit={submitform}>
               <input onChange={Changedata} type="text" name="username" placeholder="create username"/><br/>
               <input onChange={Changedata} type="email" name="email" placeholder="enter email"/><br/>
               <input onChange={Changedata} type="password" name="password" placeholder="enter password"/><br/>
               <button type="submit">Register</button>
           </form>
           
        </>
    )
}
export default Register



