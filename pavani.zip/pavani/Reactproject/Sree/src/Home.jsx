import { Link } from "react-router-dom"

function Home()
{
    return(
        <>
           <h1>welcome Home</h1>
           <Link to="/reg">click here to Register</Link><br/>
           <Link to="/log">click here to Login</Link>
        </>
    )
}
export default Home