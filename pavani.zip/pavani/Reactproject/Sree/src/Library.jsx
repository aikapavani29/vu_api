import axios from "axios";
import { useState } from "react";
import { Link } from "react-router-dom"

function Library()
{
    const [result,setResult]=useState([]);
    const viewallbooks = async (e) =>
    {
        e.preventDefault();
        const response = await axios.post("http://localhost:2913/book")
        setResult(response.data)

    }
    return(
        <>
           <h1>you are library...</h1>
           <Link to="/abook">add book</Link><br/>
           <button onClick={viewallbooks}>view all books</button>
           <Link to="/vauthorbooks">view books by author name</Link>
           
           {
            result.map(x =>(
              <li>
                {x.title}  {x.author}  {x.description}
              </li>
           )
           )
           }
        </>
    )
}
export default Library